ajit_C_system_model -u 64 -m c_conv.mmap.remapped -d -r main.results -l main.log -i 0x40000000 -w main.wtrace
