rm -f *.mmap* *.vars *.elf *.obj* *.hex *.log
rm -rf sparc-*
rm -f custom*
rm -f *.wtrace*
rm -f __gen*
rm -f *.cap
