# Steps to compile and simulate:
- To set the env variables source `set_env.sh`
- To compile and link the program run `compile_for_ajit_uclibc.sh` in the BIGMEM folder.
- To simulate using the C model of AJIT the program run `run_on_c.sh`.

> ajit-toolchain/docs/c_model/ajit_C_system_model.txt for details about different options for the C model.
