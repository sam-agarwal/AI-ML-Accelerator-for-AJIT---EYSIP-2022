ajit_C_system_model -m vector_sum.mmap.remapped -d -r main.results -l main.log -i 0x40000000 -u 64 -w main.wtrace
