#!/usr/bin/env bash

# build the project

cortos2 build "$@";

