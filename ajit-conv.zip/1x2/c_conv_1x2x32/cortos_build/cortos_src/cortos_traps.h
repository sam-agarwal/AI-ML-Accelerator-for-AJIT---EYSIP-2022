
#include <stdint.h>

/*
Invoke a software trap from 1 to 15 only.
*/
void cortos_trap(uint8_t index);